<!--  -->
<template>
  <div class="">
      <orderListHeader/>
  </div>
</template>

<script>
import orderListHeader from '././page/orderListHeader'
export default {
  data () {
    return {
    };
  },

  components: {
    orderListHeader,
  },

//   computed: {},

//   mounted: {},

//   methods: {}
}

</script>
<style scoped>
</style>